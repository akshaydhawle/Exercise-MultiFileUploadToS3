export const AWS = {
  REGION: "us-east-1",
  ACCESS_KEY: "AKIAYXB3SQULX2V6V7BK",
  SECRET_KEY: "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",
  S3: { BUCKET: "pledger-app", ENV_FOLDER: "users" },
};
